import './App.css';
import ReactSpeedometer from "react-d3-speedometer";
import React, { useState } from 'react'


function App() {
  const [volume, setVolume] = useState(1)
  const finalVolume = volume * 100
  const [volume2, setVolume2] = useState(1)
  const finalVolume2 = volume2 * 100
  const options = {
    animationEnabled: true,	
    title:{
      text: "Number of New Customers"
    },
    axisY : {
      title: "Number of Customers"
    },
    toolTip: {
      shared: true
    },
    data: [{
      type: "spline",
      name: "2016",
      showInLegend: true,
      dataPoints: [
        { y: 155, label: "Jan" },
        { y: 150, label: "Feb" },
        { y: 152, label: "Mar" },
        { y: 148, label: "Apr" },
        { y: 142, label: "May" },
        { y: 150, label: "Jun" },
        { y: 146, label: "Jul" },
        { y: 149, label: "Aug" },
        { y: 153, label: "Sept" },
        { y: 158, label: "Oct" },
        { y: 154, label: "Nov" },
        { y: 150, label: "Dec" }
      ]
    },
    {
      type: "spline",
      name: "2017",
      showInLegend: true,
      dataPoints: [
        { y: 172, label: "Jan" },
        { y: 173, label: "Feb" },
        { y: 175, label: "Mar" },
        { y: 172, label: "Apr" },
        { y: 162, label: "May" },
        { y: 165, label: "Jun" },
        { y: 172, label: "Jul" },
        { y: 168, label: "Aug" },
        { y: 175, label: "Sept" },
        { y: 170, label: "Oct" },
        { y: 165, label: "Nov" },
        { y: 169, label: "Dec" }
      ]
    }]
}

  return (
    <>
      <div class="main">
        <div class="left">
          <div className="header">
            <div class="A-Fram">
              <div class="text">----------------------A-FRAME(TON)----</div>
              <div className="Abtn">
                <button class="btn-agroup"><span>M2</span><br />0</button>
                <button class="btn-agroup" style={{ opacity: "0.3" }}><span>M</span><br />0</button>
                <button class="btn-agroup" style={{ opacity: "0.3" }}><span>M</span><br />0</button>
                <button class="btn-agroup"><span>M3</span><br />0</button>
                <button class="btn-agroup" style={{ opacity: "0.3" }}><span>M</span><br />0</button>
                <button class="btn-agroup" style={{ opacity: "0.3" }}><span>M</span><br />0</button>
              </div>

            </div>
            <div className="jlb">
              <div class="text">----------------------JIB(TON)----</div>
              <div className="jbtn">
                <button class="btn-jgroup"><span>M1</span><br />0</button>
                <button class="btn-jgroup"><span>M4</span><br />0</button>
                <button class="btn-jgroup" style={{ opacity: "0.3" }}><span>M</span><br />0</button>
                <button class="btn-jgroup" style={{ opacity: "0.3" }}><span>M</span><br />0</button>
                <button class="btn-jgroup" style={{ opacity: "0.3" }}><span>M</span><br />0</button>
                <button class="btn-jgroup" style={{ opacity: "0.3" }}><span>M</span><br />0</button>
              </div>
            </div>

          </div>
          <div class="phase2">
            <h5>A-FRAME&JIB(TON)</h5>
            <div class="slide bar">
              <div class="Afram">
                <p>A-Frame</p>
                <input type="range" min={0} max={1} step={0.0002} value={volume} onChange={event => { setVolume(event.target.valueAsNumber) }}></input>
                <span>{finalVolume.toFixed(3)}</span>
              </div>
              <div class="JIB">
                <p>JIB</p>
                <input type="range" min={0} max={1} step={0.0002} value={volume2} onChange={event => { setVolume2(event.target.valueAsNumber) }}></input>
                <span>{finalVolume2.toFixed(3)}</span>
              </div>

            </div>

          </div>
          <div class="phase3">
            <div className="App" >

              <ReactSpeedometer maxSegmentLabels={5}
                segments={5}
                value={volume * 1000}
                startColor="#02ffa2"
                endColor="#1e2832"
                needleColor="#D8DEE9"
              />
            </div>
            <CanvasJSChart options = {options} 
				/* onRef={ref => this.chart = ref} */
			/>
          </div>
      
        </div>
        <div class="right">

          <iframe src="https://www.openstreetmap.org/export/embed.html?bbox=-0.004017949104309083%2C51.47612752641776%2C0.00030577182769775396%2C51.478569861898606&layer=mapnik" title="Map" style={{ height: "800px", width: "100%" }}></iframe>
        </div>


      </div>
    </>
  );
}

export default App;
