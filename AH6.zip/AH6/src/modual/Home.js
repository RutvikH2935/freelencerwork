import axios from 'axios';
import React,{useState,useEffect} from 'react'

export const Home = () => {
    const url='http://localhost:5000/';
    const [product,setProduct]=useState(null);
    
    useEffect(()=>{
        axios.get(url).then(response=>{
            setProduct(response.data)
        },[url])
    })
    console.log(product);
  return (
    <div>{product.JIBMAX}</div>
  )
}
