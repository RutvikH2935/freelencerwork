import './App.css';
import ReactSpeedometer from 'react-d3-speedometer';
import axios from 'axios';
import React,{useState,useEffect} from 'react'

import {
  LineChart,
  ResponsiveContainer,
  Legend,
  Tooltip,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';

const pdata = [
  {
    name: 'm0',
    student: 11,
    
  },
  
];
const pdata1 = [
  {
    name: 'm0',
    student: 11,
    
  },
  
];

function App() {
  const url='http://localhost:5000/';
    const [product,setProduct]=useState(null);
    
  useEffect( async ()=>{
        await axios.get(url).then((response)=>{
        setProduct(response.data)
        
        
    },[]).catch((err)=>{
      console.log("hii");
    })
    });
    var afmax;
    if (product!=null)
    {
      console.log(product.jibmax);
    }
  const [volume, setVolume] = useState(1);
  const finalVolume = volume * 100;
  const [volume2, setVolume2] = useState(1);
  const finalVolume2 = volume2 * 100;

  return (
    <>
      <div className="main">
        <div className="left">
          <div className="header">
            <div className="A-Fram">
              <div className="aframe">
                <div className="text">
                  <h3>---------------------- A-FRAME(TON) ----</h3>
                </div>
                <div className="Abtn"> 
                  <button className="btn-agroup">
                    <span>M2</span>
                    <br />0
                  </button>
                  <button className="btn-agroup" style={{opacity: '0.3'}}>
                    <span>M</span>
                    <br />0
                  </button>
                  <button className="btn-agroup" style={{opacity: '0.3'}}>
                    <span>M</span>
                    <br />0
                  </button>
                  <button className="btn-agroup">
                    <span>M3</span>
                    <br />0
                  </button>
                  <button className="btn-agroup" style={{opacity: '0.3'}}>
                    <span>M</span>
                    <br />0
                  </button>
                  <button className="btn-agroup" style={{opacity: '0.3'}}>
                    <span>M</span>
                    <br />0
                  </button>
                </div>
              </div>
             <div className="aframe">
              <div className="text">
                <h3>---------------------- JIB(TON) ----</h3>
              </div>
              <div className="jlb">
                <div className="jbtn">
                  <button className="btn-jgroup">
                    <span>M1</span>
                    <br />0
                  </button>
                  <button className="btn-jgroup">
                    <span>M4</span>
                    <br />0
                  </button>
                  <button className="btn-jgroup" style={{opacity: '0.3'}}>
                    <span>M</span>
                    <br />0
                  </button>
                  <button className="btn-jgroup" style={{opacity: '0.3'}}>
                    <span>M</span>
                    <br />0
                  </button>
                  <button className="btn-jgroup" style={{opacity: '0.3'}}>
                    <span>M</span>
                    <br />0
                  </button>
                  <button className="btn-jgroup" style={{opacity: '0.3'}}>
                    <span>M</span>
                    <br />0
                  </button>
                </div>
              </div>
             </div>
           
            </div>
          </div>

          <div className="phase2">
            <div className="heading">
              <h3>A-FRAME&JIB(TON)</h3>
            </div>
            <div className="App" id="phase2">
              <div className="input">
                <p>A-Frame</p>
                <div className="Afram">
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.0002}
                    value={product.afmax}
                    onChange={event => {
                      setVolume(event.target.valueAsNumber);
                    }}></input>
                </div>
              </div>
              <span className='speedspan'>{15}</span>
              <div className="input">
                <p>JIB</p>
                <div className="JIB">
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.0002}
                    value={product.jibmax}
                    onChange={event => {
                      setVolume2(event.target.valueAsNumber);
                    }}></input>
                </div>
              </div>
              <span className='speedspan'>{finalVolume2.toFixed(3)}</span>
              <div className="rescontainer">
                <ResponsiveContainer width="100%" aspect={3}>
                  <LineChart data={pdata} margin={{right: 300}}>
                    <CartesianGrid />
                    <XAxis dataKey="name" interval={'preserveStartEnd'} />
                    <YAxis></YAxis>
                    <Legend />
                    <Tooltip />
                    <Line dataKey="student" stroke="black" activeDot={{r: 8}} />
                    <Line dataKey="fees" stroke="red" activeDot={{r: 8}} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="phase3">
            <div className="heading">
              <h3>Boom Angle(Degree)</h3>
            </div>
            <div className="App" id="phase3">
              <div className="speedometer">
                <ReactSpeedometer
                  maxSegmentLabels={5}
                  segments={5}
                  value={volume * 1000}
                  startColor="#02ffa2"
                  width={300}
                  height={300}
                  ringWidth={70}
                  endColor="#1e2832"
                  needleColor="#D8DEE9"
                />
              </div>
              <div className="chart">
                <ResponsiveContainer width="100%" height="100%" aspect={3}>
                  <LineChart data={pdata1} margin={{right: 300}}>
                    <CartesianGrid />
                    <XAxis dataKey="name" interval={'preserveStartEnd'} />
                    <YAxis></YAxis>
                    <Legend />
                    <Tooltip />
                    <Line dataKey="student" stroke="black" activeDot={{r: 8}} />
                    <Line dataKey="fees" stroke="red" activeDot={{r: 8}} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
        <div className="right">
          <iframe
            src="https://www.openstreetmap.org/export/embed.html?bbox=-0.004017949104309083%2C51.47612752641776%2C0.00030577182769775396%2C51.478569861898606&layer=mapnik"
            title="Map"
            style={{height: '800px', width: '100%'}}></iframe>
        </div>
      </div>
    </>
  );
}

export default App;